﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Animal
    {
        string nombre;

        public Animal(string nombre)
        {
            this.nombre = nombre;
        }
    }
}
