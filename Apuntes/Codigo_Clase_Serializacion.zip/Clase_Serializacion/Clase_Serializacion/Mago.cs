﻿namespace Clase_Serializacion
{
    public class Mago : Personaje
    {
        private int puntosDeMana;

        public int PuntosDeMana
        {
            get 
            {
                return puntosDeMana;
            }
            set
            {
                puntosDeMana = value;
            }
        }


        public Mago(int puntosDeVida, string nombre, int puntosDeMana)
            :base(puntosDeVida, nombre)
        {
            this.puntosDeMana = puntosDeMana;
        }

        public override string ToString()
        {
            return $"{base.ToString()} - {puntosDeMana} puntos de mana.";
        }
    }
}
