﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Xml.Serialization;

namespace Clase_Serializacion
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    string rutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        //    string rutaArchivo = Path.Combine(rutaEscritorio, "personaje.xml");

        //    //Personaje mago = new Mago(100, "Carpincho místico", 250);
        //    //Personaje guerrero = new Guerrero(100, "Carpincho Asesino", 500);

        //    //List<Personaje> personajes = new List<Personaje>()
        //    //{
        //    //    mago,
        //    //    guerrero
        //    //};

        //    //SerializarAXml(rutaArchivo, personajes);

        //    //List<Personaje> personajes = DeserializarDesdeXml<List<Personaje>>(rutaArchivo);

        //    //foreach (Personaje personaje in personajes)
        //    //{
        //    //    Console.WriteLine(personaje);
        //    //}
        //}

        private static void SerializarAXml<T>(string ruta, T objeto)
        {
            using(StreamWriter streamWriter = new StreamWriter(ruta))
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
                xmlSerializer.Serialize(streamWriter, objeto);
            }
        }

        private static T DeserializarDesdeXml<T>(string ruta)
            where T : class
        {
            using (StreamReader streamReader = new StreamReader(ruta))
            {
                XmlSerializer xmlSerializer = new XmlSerializer(typeof(T));
                T objeto = xmlSerializer.Deserialize(streamReader) as T;
                return objeto;
            }
        }

        static void Main(string[] args)
        {
            string rutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string rutaArchivo = Path.Combine(rutaEscritorio, "personaje.json");

            Personaje mago = new Mago(100, "Carpincho místico", 250);
            Personaje guerrero = new Guerrero(100, "Carpincho Asesino", 500);
            List<Personaje> nuevosPersonajes = new List<Personaje>()
            {
                mago,
                guerrero
            };

            SerializarAJson(rutaArchivo, nuevosPersonajes);

            List<Personaje> personajes = DeserializarDesdeJson<List<Personaje>>(rutaArchivo);
            
            foreach (Personaje personaje in personajes)
            {
                Console.WriteLine(personaje);
            }
        }

        private static void SerializarAJson<T>(string ruta, T objeto)
        {
            JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions();
            jsonSerializerOptions.WriteIndented = true;

            string objetoJson = JsonSerializer.Serialize<object>(objeto, jsonSerializerOptions);

            File.WriteAllText(ruta, objetoJson);
        }

        private static T DeserializarDesdeJson<T>(string ruta)
        {
            string objetoJson = File.ReadAllText(ruta);

            T objeto = JsonSerializer.Deserialize<T>(objetoJson);

            return objeto;
        }
    }
}
