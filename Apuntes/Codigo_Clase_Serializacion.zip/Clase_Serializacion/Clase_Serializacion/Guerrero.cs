﻿namespace Clase_Serializacion
{
    public class Guerrero : Personaje
    {
        private int puntosDeFuerza;

        public int PuntosDeFuerza
        {
            get 
            {
                return puntosDeFuerza;
            }
            set
            {
                puntosDeFuerza = value;
            }
        }


        public Guerrero(int puntosDeVida, string nombre, int puntosDeFuerza)
            :base(puntosDeVida, nombre)
        {
            this.puntosDeFuerza = puntosDeFuerza;
        }

        public override string ToString()
        {
            return $"{base.ToString()} - {puntosDeFuerza} puntos de fuerza.";
        }
    }
}
