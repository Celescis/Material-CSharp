﻿using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace Clase_Serializacion
{
    [XmlInclude(typeof(Mago))]
    [XmlInclude(typeof(Guerrero))]
    public class Personaje
    {
        private int puntosDeVida;
        private string nombre;

        public int PuntosDeVida
        {
            get
            {
                return puntosDeVida;
            }
            set
            {
                puntosDeVida = value;
            }
        }

        public string Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }

        public Personaje(int puntosDeVida, string nombre)
        {
            this.puntosDeVida = puntosDeVida;
            this.nombre = nombre;
        }

        public override string ToString()
        {
            return $"{nombre} - {puntosDeVida} puntos de vida";
        }
    }
}
